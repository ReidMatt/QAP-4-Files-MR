valid_provinces = ['ON', 'QC', 'BC', 'AB','MB', 'SK', 'NS', 'NB', 'PE', 'NT', 'NL', 'YT', 'NU']

#Function to validate province
def validate_province(province):
  return province.upper() in valid_provinces

province_iput = input("Enter customer's province (2-letter abbreviation): ").upper()
if validate_province:
  print("Province is valid.")
else:
  print("Invalid province. Please enter a valid 2 letter abbreviation.")

#Valid payment options
validate_payment_options = ['Full', 'Monthly,' 'Down Payment']

#Function to validate payment option
def validate_payment_option(option):
  return option.title() in validate_payment_option

payment_input = input("Enter payment method (Full/Monthly/Down Pay): ").title()
if validate_payment_option:
  print("Payment method is valid.")
else:
    print("Invalid payment method. Please enter a valid option.")
